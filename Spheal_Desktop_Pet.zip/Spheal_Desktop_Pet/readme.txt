Crewmate_Pet is a Windows desktop mascot that freely wanders and plays around the screen.  The mascot is very configurable; its actions are defined through xml and its animations/images can be (painstakingly) customized.  Shimeji was originally created by Yuki Yamada of Group Finity (http://www.group-finity.com/Shimeji/).  This branch of the original Shimeji project not only translates the program/source to English, but adds additional enhancements to Shimeji.

====  Thanks  ====

based on the amongus/Shimeji Project
By Kilkakon
kilkakon.com
(look at licence.txt)

==== Requirements ==== 

1. Windows XP or higher
2. Java

==== How to Start ==== 

Double Click the Crewmate_Pet file (Crewmate_Pet.jar).

Right click the tray icon for general options.

Right click a Shimeji for options relating to it.





The following actions must be present for the actions.xml to be valid:

ChaseMouse
Fall
Dragged
Thrown

The following behaviors must be present for the behaviors.xml to be valid:

ChaseMouse
Fall
Dragged
Thrown

The icon used for the system tray is img/icon.png

==== How to Quit ==== 

Right-click the tray icon of Shimeji, Select "Dismiss All"

==== How to Uninstall ==== 

Delete the unzipped folder.

